import { Sun, Moon } from "lucide-react";
import { useTheme } from "../hooks/use-theme";

const ThemeToggle = () => {
  const { theme, setTheme } = useTheme();

  return (
    <button 
      className="fixed bottom-4 left-4 p-2 rounded-full bg-secondary hover:bg-secondary/80 text-foreground shadow-lg transition-colors"
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}
    >
      {theme === "dark" ? <Sun size={20} /> : <Moon size={20} />}
    </button>
  );
};

export default ThemeToggle; 