import React from "react";
import { SystemInstructions } from "../services/aiService";

interface SystemInstructionsFormProps {
  instructions: SystemInstructions;
  onChange: (field: keyof SystemInstructions, value: string) => void;
  onGeneratePrompt: () => void;
  isGenerating: boolean;
}

const SystemInstructionsForm: React.FC<SystemInstructionsFormProps> = ({
  instructions,
  onChange,
  onGeneratePrompt,
  isGenerating
}) => {
  return (
    <div className="flex flex-col gap-2 p-3 border border-border rounded-lg shadow-sm">
      <h2 className="text-xl font-semibold mb-0.5">System Instructions</h2>

      <div className="space-y-2">
        <div>
          <label className="block mb-0.5">Expert Role</label>
          <textarea
            className="w-full bg-muted text-foreground border border-border rounded p-2 h-20 resize-vertical"
            placeholder="Define the expert role..."
            value={instructions.expertRole}
            onChange={(e) => onChange("expertRole", e.target.value)}
          />
        </div>

        <div>
          <label className="block mb-0.5">Domain Expert Areas</label>
          <textarea
            className="w-full bg-muted text-foreground border border-border rounded p-2 h-20 resize-vertical"
            placeholder="Specify domain expertise..."
            value={instructions.domainExpertAreas}
            onChange={(e) => onChange("domainExpertAreas", e.target.value)}
          />
        </div>

        <div>
          <label className="block mb-0.5">Analytical and Reasoning Methods</label>
          <textarea
            className="w-full bg-muted text-foreground border border-border rounded p-2 h-20 resize-vertical"
            placeholder="Define analytical approaches..."
            value={instructions.analyticalMethods}
            onChange={(e) => onChange("analyticalMethods", e.target.value)}
          />
        </div>

        <div>
          <label className="block mb-0.5">Default Actions</label>
          <textarea
            className="w-full bg-muted text-foreground border border-border rounded p-2 h-20 resize-vertical"
            placeholder="Specify default actions..."
            value={instructions.defaultActions}
            onChange={(e) => onChange("defaultActions", e.target.value)}
          />
        </div>

        <div>
          <label className="block mb-0.5">Communication Style</label>
          <textarea
            className="w-full bg-muted text-foreground border border-border rounded p-2 h-20 resize-vertical"
            placeholder="Define communication style..."
            value={instructions.communicationStyle}
            onChange={(e) => onChange("communicationStyle", e.target.value)}
          />
        </div>

        <div>
          <label className="block mb-0.5">Don'ts</label>
          <textarea
            className="w-full bg-muted text-foreground border border-border rounded p-2 h-20 resize-vertical"
            placeholder="Specify restrictions..."
            value={instructions.donts}
            onChange={(e) => onChange("donts", e.target.value)}
          />
        </div>

        <div>
          <label className="block mb-0.5 text-center text-lg font-medium">Additional Information</label>
          <textarea
            className="w-full bg-muted text-foreground border border-border rounded p-2 h-28 resize-vertical"
            placeholder="Add any additional context or requirements..."
            value={instructions.additionalInformation}
            onChange={(e) => onChange("additionalInformation", e.target.value)}
          />
        </div>
      </div>

      <div className="flex justify-end mt-2">
        <button
          onClick={onGeneratePrompt}
          disabled={isGenerating}
          className="bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-1 rounded-md text-sm"
        >
          {isGenerating ? "Generating..." : "Generate Prompt"}
        </button>
      </div>
    </div>
  );
};

export default SystemInstructionsForm;
