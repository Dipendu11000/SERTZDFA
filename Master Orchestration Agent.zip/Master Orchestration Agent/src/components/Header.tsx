import { Link } from "react-router-dom";
import { HelpCircle, Info } from "lucide-react";
import { useIsMobile } from "../hooks/use-mobile";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import synchronyLogo from "../assets/synchrony-logo.png";

const Header = () => {
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const location = useLocation();

  const handleSignOut = () => {
    localStorage.removeItem("isSignedIn");
    window.location.reload();
  };

  const tabs = [
    { path: "/", name: "Generate Prompt" },
    { path: "/prompts", name: "PromptDB" },
    { path: "/chat", name: "Test" },
    { path: "/feedback", name: "Feedback" },
  ];

  return (
    <header className="bg-secondary py-3 px-3 sm:px-6 flex flex-col sm:flex-row justify-between items-center border-b border-border">
      <div className="flex items-center gap-3">
        <img src={synchronyLogo} alt="Synchrony Logo" className="h-8 w-8 rounded" />
        <h1 className="text-xl font-bold text-foreground mb-2 sm:mb-0">Master Orchestration Agent</h1>
      </div>
      
      <nav className="flex items-center gap-4 flex-wrap">
        {[
          { path: "/chat", name: "Test" }
        ].map((tab) => (
          <Link
            key={tab.path}
            to={tab.path}
            className={`px-3 py-1.5 rounded-md text-sm transition-colors border border-border shadow-sm font-medium
              ${location.pathname === tab.path
                ? "bg-primary text-primary-foreground border-primary shadow"
                : "bg-card text-foreground hover:bg-muted/50"}
            `}
          >
            {tab.name}
          </Link>
        ))}
        <Link
          to="/help"
          className={`p-1.5 rounded-md transition-colors flex items-center justify-center
            ${location.pathname === "/help"
              ? "text-primary"
              : "hover:text-primary text-foreground"}
          `}
          style={{ minWidth: 36, background: 'none', border: 'none', boxShadow: 'none' }}
        >
          <HelpCircle size={18} />
        </Link>
        <Link
          to="/about"
          className={`p-1.5 rounded-md transition-colors flex items-center justify-center
            ${location.pathname === "/about"
              ? "text-primary"
              : "hover:text-primary text-foreground"}
          `}
          style={{ minWidth: 36, background: 'none', border: 'none', boxShadow: 'none' }}
        >
          <Info size={18} />
        </Link>
        <button
          className="ml-2 bg-yellow-400 hover:bg-yellow-500 text-yellow-900 font-semibold px-3 py-1 rounded transition-colors"
          style={{ zIndex: 10 }}
          onClick={handleSignOut}
        >
          Sign Out
        </button>
      </nav>
    </header>
  );
};

export default Header;
