import React from "react";
import { GenerationParams } from "../services/aiService";
import { Info, Edit2, Save, ChevronDown } from "lucide-react";

// Mock usecases
const useCases = [
  "Business Insights",
  "Marketing Charts",
  "Sales Presentation",
  "Financial Analysis",
  "Product Research",
];

// Mock LLM models
const llmModels = [
  "Gemini",
  "GPT-4o",
  "Nova Pro",
  "Nova Lite",
  "Clause",
  "GPT 3",
];

interface PromptGeneratorProps {
  onGeneratedPrompt: (prompt: string) => void;
  generationParams: GenerationParams;
  setGenerationParams: (params: GenerationParams) => void;
  availableUseCases?: string[];
}

const PromptGenerator: React.FC<PromptGeneratorProps> = ({ 
  onGeneratedPrompt, 
  generationParams, 
  setGenerationParams,
  availableUseCases
}) => {
  const [selectedUseCase, setSelectedUseCase] = React.useState("Business Insights");
  const [selectedModel, setSelectedModel] = React.useState("Gemini");
  const [showSystemPrompt, setShowSystemPrompt] = React.useState(false);
  const [isEditing, setIsEditing] = React.useState(false);
  const [systemPrompt, setSystemPrompt] = React.useState(`You are an expert persona formatter. User gives structured inputs like: "Role/Persona", "Domain Mastery Areas", "Analytical Behavior and Reasoning Methods", "Communication Style", "Default Actions", "Don'ts", "Additional Information", and so on.. Your job is to convert these into a precise, clean, 12–15 point persona-style system prompt. The output should reflect the expert's mindset, reasoning style, working patterns, communication tone, strengths, priorities, and cautionary rules.`);

  // Use only marketing usecases for now
  const marketingUseCases = [
    "Business Insights",
    "Marketing Charts",
    "Campaign Analysis",
    "Social Media Strategy",
    "Brand Monitoring"
  ];
  const useCaseOptions = marketingUseCases;

  const handleParamChange = (param: keyof GenerationParams, value: string) => {
    const numValue = parseFloat(value);
    if (!isNaN(numValue)) {
      setGenerationParams({ ...generationParams, [param]: numValue });
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="p-3 flex flex-col gap-3 w-full">
        <div className="bg-card rounded-lg p-3 border border-border shadow-sm">
          <h3 className="font-medium mb-2">UseCase</h3>
          <select
            value={selectedUseCase}
            onChange={(e) => setSelectedUseCase(e.target.value)}
            className="w-full bg-muted text-foreground border border-border rounded p-2"
          >
            {useCaseOptions.map((useCase) => (
              <option key={useCase} value={useCase}>
                {useCase}
              </option>
            ))}
          </select>
        </div>

        <div className="bg-card rounded-lg p-3 border border-border shadow-sm">
          <h3 className="font-medium mb-2">LLM Model</h3>
          <select
            value={selectedModel}
            onChange={(e) => setSelectedModel(e.target.value)}
            className="w-full bg-muted text-foreground border border-border rounded p-2"
          >
            {llmModels.map((model) => (
              <option key={model} value={model}>
                {model}
              </option>
            ))}
          </select>
        </div>

        <div className="bg-card rounded-lg p-3 border border-border shadow-sm">
          <h3 className="font-medium mb-2">Parameters</h3>
          <div className="space-y-2">
            <div className="flex items-center">
              <label className="w-24 text-sm">Temperature</label>
              <input
                type="number"
                min="0"
                max="1"
                step="0.1"
                value={generationParams.temperature}
                onChange={(e) => handleParamChange("temperature", e.target.value)}
                className="flex-1 bg-muted text-foreground border border-border rounded p-1 text-sm"
              />
            </div>
            <div className="flex items-center">
              <label className="w-24 text-sm">Top P</label>
              <input
                type="number"
                min="0"
                max="1"
                step="0.1"
                value={generationParams.topP}
                onChange={(e) => handleParamChange("topP", e.target.value)}
                className="flex-1 bg-muted text-foreground border border-border rounded p-1 text-sm"
              />
            </div>
            <div className="flex items-center">
              <label className="w-24 text-sm">Top K</label>
              <input
                type="number"
                min="1"
                max="100"
                step="1"
                value={generationParams.topK}
                onChange={(e) => handleParamChange("topK", e.target.value)}
                className="flex-1 bg-muted text-foreground border border-border rounded p-1 text-sm"
              />
            </div>
          </div>
        </div>

        {/* System Prompt Button */}
        <button
          onClick={() => setShowSystemPrompt(!showSystemPrompt)}
          className="bg-card hover:bg-card/80 text-foreground border border-border rounded-lg p-3 shadow-sm flex items-center justify-between"
        >
          <span className="font-medium">System Prompt</span>
          <ChevronDown className={`w-4 h-4 transition-transform ${showSystemPrompt ? 'rotate-180' : ''}`} />
        </button>

        {/* System Prompt Text Box */}
        {showSystemPrompt && (
          <div className="bg-card rounded-lg p-3 border border-border shadow-sm">
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-medium">System Context</h3>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="text-muted-foreground hover:text-foreground"
              >
                {isEditing ? <Save className="w-4 h-4" /> : <Edit2 className="w-4 h-4" />}
              </button>
            </div>
            <textarea
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              disabled={!isEditing}
              className="w-full bg-muted text-foreground border border-border rounded p-2 h-32 resize-vertical"
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default PromptGenerator;
