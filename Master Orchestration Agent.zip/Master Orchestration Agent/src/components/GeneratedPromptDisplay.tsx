import React, { useState, useEffect, useRef } from "react";
import { toast } from "sonner";
import { X, Plus, ChevronDown, Send } from "lucide-react";
import { useIsMobile } from "../hooks/use-mobile";
import { useNavigate } from "react-router-dom";

interface GeneratedPromptDisplayProps {
  generatedPrompt: string;
  onSaveToDb: (prompt: string) => void;
}

interface PromptTab {
  id: string;
  name: string;
  content: string;
}

const GENERATED_PROMPT_KEY = "synchrony_generated_prompt";

const GeneratedPromptDisplay: React.FC<GeneratedPromptDisplayProps> = ({
  generatedPrompt,
  onSaveToDb
}) => {
  const [tabs, setTabs] = useState<PromptTab[]>([
    { id: "1", name: "Prompt Test 1", content: "" }
  ]);
  const [activeTabId, setActiveTabId] = useState<string>("1");
  const [manualPrompt, setManualPrompt] = useState<string>("");
  const [viewMode, setViewMode] = useState<"generated" | "manual">("generated");
  const [exportFormat, setExportFormat] = useState<string>("pdf");
  const [showConfirmation, setShowConfirmation] = useState<string | null>(null);
  const [showExportDropdown, setShowExportDropdown] = useState<boolean>(false);
  const [showTestDropdown, setShowTestDropdown] = useState<boolean>(false);
  const [selectedTest, setSelectedTest] = useState<string>("Test");
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const exportDropdownRef = useRef<HTMLDivElement>(null);
  const testDropdownRef = useRef<HTMLDivElement>(null);

  // Handle clicks outside the dropdowns
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (exportDropdownRef.current && !exportDropdownRef.current.contains(event.target as Node)) {
        setShowExportDropdown(false);
      }
      if (testDropdownRef.current && !testDropdownRef.current.contains(event.target as Node)) {
        setShowTestDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Optimize by only updating when generatedPrompt changes
  useEffect(() => {
    if (generatedPrompt) {
      setTabs(prevTabs => {
        // Create a new array to avoid mutation
        return prevTabs.map(tab => 
          tab.id === "1" ? { ...tab, content: generatedPrompt } : tab
        );
      });
    }
  }, [generatedPrompt]);

  useEffect(() => {
    // Load from localStorage if not present
    if (!generatedPrompt) {
      const stored = localStorage.getItem(GENERATED_PROMPT_KEY);
      if (stored) {
        setTabs(prevTabs => prevTabs.map(tab => tab.id === "1" ? { ...tab, content: stored } : tab));
      }
    }
  }, [generatedPrompt]);

  const handleAddTab = () => {
    // Find the highest ID and increment by 1
    const newId = (Math.max(0, ...tabs.map(tab => parseInt(tab.id, 10))) + 1).toString();
    setTabs(prev => [...prev, { id: newId, name: `Prompt Test ${newId}`, content: "" }]);
    setActiveTabId(newId);
  };

  const handleCloseTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length <= 1) {
      return; // Don't remove the last tab
    }
    
    setShowConfirmation(id);
  };
  
  const confirmCloseTab = (id: string) => {
    const updatedTabs = tabs.filter(tab => tab.id !== id);
    setTabs(updatedTabs);
    
    // If we're closing the active tab, switch to the first available tab
    if (activeTabId === id) {
      setActiveTabId(updatedTabs[0].id);
    }
    
    setShowConfirmation(null);
  };

  const handleSaveToDb = () => {
    const contentToSave = viewMode === "generated" 
      ? tabs.find(tab => tab.id === activeTabId)?.content || "" 
      : manualPrompt;
      
    onSaveToDb(contentToSave);
    toast.success("Prompt saved to PromptDB");
  };

  const handleExport = (format: string) => {
    const contentToExport = viewMode === "generated" 
      ? tabs.find(tab => tab.id === activeTabId)?.content || "" 
      : manualPrompt;
    
    toast.success(`Prompt exported as ${format.toUpperCase()}`);
    
    // Create a data blob and trigger download
    const blob = new Blob([contentToExport], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `prompt-export.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url); // Clean up to avoid memory leaks
    
    setShowExportDropdown(false);
  };

  const navigateToTest = () => {
    navigate("/chat");
  };

  // Get active tab content
  const activeTabContent = tabs.find(tab => tab.id === activeTabId)?.content || "";

  return (
    <div className="flex flex-col h-full p-2 border border-border rounded-lg shadow-sm">
      <h2 className="text-xl font-semibold mb-1">Generated Context Prompt</h2>
      
      <div className="flex flex-wrap gap-1 mb-1 items-center">
        <div className="flex flex-wrap gap-1 flex-1 mb-1">
          {tabs.map(tab => (
            <div 
              key={tab.id}
              className={`px-2 py-1 rounded-md cursor-pointer flex items-center text-xs border transition-colors ${activeTabId === tab.id ? "bg-yellow-300/80 text-yellow-900 border-yellow-400" : "bg-card text-foreground border-border"}`}
              onClick={() => {
                setActiveTabId(tab.id);
                setViewMode("generated");
              }}
            >
              <span className="truncate max-w-[80px]">{tab.name}</span>
              {tabs.length > 1 && (
                <button 
                  className="ml-1 bg-transparent hover:bg-primary-foreground/20 rounded-full w-4 h-4 flex items-center justify-center"
                  onClick={(e) => handleCloseTab(tab.id, e)}
                  aria-label={`Close tab ${tab.name}`}
                >
                  <X size={10} />
                </button>
              )}
            </div>
          ))}
          <button 
            className="w-5 h-5 rounded-full bg-secondary text-foreground hover:bg-secondary/80 flex items-center justify-center"
            onClick={handleAddTab}
            aria-label="Add new tab"
          >
            <Plus size={12} />
          </button>
        </div>
        
        <div className="flex items-center">
          <div 
            className={`px-2 py-1 rounded-md cursor-pointer text-xs ${viewMode === "manual" ? "bg-primary text-black" : "bg-secondary text-foreground"}`}
            onClick={() => setViewMode("manual")}
          >
            Manual Prompt
          </div>
        </div>
      </div>

      {viewMode === "generated" ? (
        <div className="bg-card rounded-md p-1.5 mb-2 overflow-y-auto border border-border h-40 sm:h-56 flex flex-col items-start justify-start">
          {activeTabContent ? (
            <pre className="whitespace-pre-wrap text-sm" dangerouslySetInnerHTML={{ __html: activeTabContent.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>') }} />
          ) : (
            <div className="text-muted-foreground text-left pt-2 pl-2">
              No prompt generated yet. Click 'Generate Prompt' to create a prompt.
            </div>
          )}
        </div>
      ) : (
        <div className="mb-3 border border-border rounded-md overflow-hidden h-48 sm:h-64">
          <textarea
            value={manualPrompt}
            onChange={(e) => setManualPrompt(e.target.value)}
            className="w-full h-full bg-card p-3 resize-none focus:outline-none text-sm"
            placeholder="Enter your manual prompt here..."
          />
        </div>
      )}

      <div className="flex flex-wrap items-center gap-1 justify-end">
        <button
          onClick={handleSaveToDb}
          disabled={viewMode === "generated" ? !activeTabContent : !manualPrompt}
          className="flex items-center gap-1 bg-secondary hover:bg-secondary/80 text-foreground px-2 py-1 rounded text-xs disabled:opacity-50"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 2v8"></path><path d="m16 6-4-4-4 4"></path>
            <rect width="20" height="8" x="2" y="14" rx="2"></rect>
          </svg>
          SAVE TO PROMPTDB
        </button>

        <div className="flex items-center gap-2">
          <div className="relative" ref={testDropdownRef}>
            <button
              onClick={() => setShowTestDropdown(!showTestDropdown)}
              className="bg-secondary hover:bg-secondary/80 text-foreground px-3 py-1 rounded text-xs disabled:opacity-50 flex items-center gap-1"
            >
              {selectedTest}
              <ChevronDown size={12} />
            </button>
            
            {showTestDropdown && (
              <div className="absolute right-0 z-10 mt-1 w-48 bg-card border border-border rounded-md shadow-lg overflow-hidden">
                <div className="py-1">
                  {tabs.map((tab) => (
                    <button 
                      key={tab.id}
                      onClick={() => {
                        setSelectedTest(`Test ${tab.name}`);
                        setShowTestDropdown(false);
                        navigate("/chat");
                      }}
                      className="w-full text-left px-4 py-2 text-xs hover:bg-muted/50"
                    >
                      {tab.name}
                    </button>
                  ))}
                  <button 
                    onClick={() => {
                      setSelectedTest("Test Manual Prompt");
                      setShowTestDropdown(false);
                      navigate("/chat");
                    }}
                    className="w-full text-left px-4 py-2 text-xs hover:bg-muted/50"
                  >
                    Manual Prompt
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="relative" ref={exportDropdownRef}>
            <button
              onClick={() => setShowExportDropdown(!showExportDropdown)}
              disabled={viewMode === "generated" ? !activeTabContent : !manualPrompt}
              className="bg-secondary hover:bg-secondary/80 text-foreground px-3 py-1 rounded text-xs disabled:opacity-50 flex items-center gap-1"
            >
              EXPORT
              <ChevronDown size={12} />
            </button>
            
            {showExportDropdown && (
              <div className="absolute right-0 z-10 mt-1 w-36 bg-card border border-border rounded-md shadow-lg overflow-hidden">
                <div className="py-1">
                  <button 
                    onClick={() => handleExport('pdf')} 
                    className="w-full text-left px-4 py-2 text-xs hover:bg-muted/50"
                  >
                    PDF
                  </button>
                  <button 
                    onClick={() => handleExport('docx')} 
                    className="w-full text-left px-4 py-2 text-xs hover:bg-muted/50"
                  >
                    DOCX
                  </button>
                  <button 
                    onClick={() => handleExport('json')} 
                    className="w-full text-left px-4 py-2 text-xs hover:bg-muted/50"
                  >
                    JSON
                  </button>
                  <button 
                    onClick={() => handleExport('txt')} 
                    className="w-full text-left px-4 py-2 text-xs hover:bg-muted/50"
                  >
                    TXT
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Confirmation Dialog */}
      {showConfirmation && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card rounded-lg p-5 max-w-md w-full">
            <h3 className="text-lg font-medium mb-2">Confirm Delete</h3>
            <p className="mb-4">Are you sure you want to delete this prompt? This action cannot be undone.</p>
            <div className="flex justify-end gap-2">
              <button 
                className="px-4 py-2 border border-border rounded-md hover:bg-secondary/20"
                onClick={() => setShowConfirmation(null)}
              >
                Cancel
              </button>
              <button 
                className="px-4 py-2 bg-destructive text-destructive-foreground rounded-md hover:bg-destructive/90"
                onClick={() => confirmCloseTab(showConfirmation)}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GeneratedPromptDisplay;
