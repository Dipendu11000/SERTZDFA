
import React, { useState } from "react";
import { Feedback } from "../types";

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  feedbacks: Feedback[];
  onUpdateFeedbacks: (feedbacks: Feedback[]) => void;
}

const FeedbackModal: React.FC<FeedbackModalProps> = ({
  isOpen,
  onClose,
  feedbacks,
  onUpdateFeedbacks,
}) => {
  if (!isOpen) return null;

  const handleToggleFeedback = (id: string) => {
    const updatedFeedbacks = feedbacks.map((feedback) =>
      feedback.id === id
        ? { ...feedback, checked: !feedback.checked }
        : feedback
    );
    onUpdateFeedbacks(updatedFeedbacks);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-card rounded-lg shadow-lg max-w-2xl w-full max-h-[80vh] overflow-hidden flex flex-col">
        <div className="p-4 border-b border-border flex justify-between items-center">
          <h3 className="text-xl font-semibold">User Feedback</h3>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground"
          >
            ×
          </button>
        </div>
        <div className="p-6 overflow-y-auto">
          {feedbacks.length === 0 ? (
            <p className="text-muted-foreground">No feedback available.</p>
          ) : (
            <ul className="space-y-3">
              {feedbacks.map((feedback) => (
                <li
                  key={feedback.id}
                  className="flex items-start gap-2 pb-3 border-b border-border"
                >
                  <input
                    type="checkbox"
                    checked={feedback.checked}
                    onChange={() => handleToggleFeedback(feedback.id)}
                    className="mt-1"
                  />
                  <span className={feedback.checked ? "line-through text-muted-foreground" : ""}>
                    {feedback.text}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="p-4 border-t border-border flex justify-end">
          <button
            onClick={onClose}
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-2 rounded"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default FeedbackModal;
