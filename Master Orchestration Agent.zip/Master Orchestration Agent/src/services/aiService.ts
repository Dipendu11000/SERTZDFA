import { GoogleGenerativeAI } from '@google/generative-ai';

// Initialize the Generative AI API with the provided API key
const genAI = new GoogleGenerativeAI("AIzaSyDsjU_Y8w07k3hHgB-fbbp0FIOVkzbGoq4");

export const BASE_PERSONA_PROMPT = `You are an expert persona formatter. User gives structured inputs like: "Role/Persona", "Domain Mastery Areas", "Analytical Behavior and Reasoning Methods", "Communication Style", "Default Actions", "Don'ts", "Additional Information", and so on.. Your job is to convert these into a precise, clean, 12–15 point persona-style system prompt.`;

export interface SystemInstructions {
  expertRole: string;
  domainExpertAreas: string;
  analyticalMethods: string;
  defaultActions: string;
  communicationStyle: string;
  donts: string;
  additionalInformation: string;
}

export interface GenerationParams {
  temperature: number;
  topP: number;
  topK: number;
}

export async function generatePrompt(
  instructions: SystemInstructions,
  params: GenerationParams
): Promise<string> {
  try {
    // Construct the prompt with all the inputs
    const fullPrompt = `
${BASE_PERSONA_PROMPT}
Here are the inputs:
Role/Persona:
${instructions.expertRole}
Domain Mastery Areas:
${instructions.domainExpertAreas}
Analytical Behavior and Reasoning Methods:
${instructions.analyticalMethods}
Default Actions:
${instructions.defaultActions}
Communication Style:
${instructions.communicationStyle}
Don'ts:
${instructions.donts}
Additional Information:
${instructions.additionalInformation}

Based on these inputs, generate the persona prompt:
`;

    // Set up the model with the specified parameters 
    const model = genAI.getGenerativeModel({
      model: "gemini-1.5-flash",
      generationConfig: {
        temperature: params.temperature,
        topP: params.topP,
        topK: params.topK,
      }
    });

    const result = await model.generateContent(fullPrompt);
    const response = await result.response;
    const text = response.text();

    return text;
  } catch (error) {
    console.error("Error generating prompt:", error);
    return "Error generating prompt. Please check your inputs and try again.";
  }
}

// Function to generate chat responses
export async function generateChatResponse(message: string): Promise<string> {
  try {
    const model = genAI.getGenerativeModel({
      model: "gemini-1.5-flash",
    });
    const result = await model.generateContent(message);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error("Error generating chat response:", error);
    return "Sorry, I couldn't process that request. Please try again.";
  }
}