import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { X, MessageSquare, ChevronLeft, ChevronRight, Plus, Send, Check, FileDown } from "lucide-react";
import { toast } from "sonner";

interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
  status?: string;
  isStatus?: boolean;
}

interface ChatSession {
  id: string;
  title: string;
  useCase: string;
  messages: ChatMessage[];
  lastUpdated: Date;
}

// Hardcoded responses for different questions
const hardcodedResponses: { [key: string]: { steps: string[], finalResponse: string } } = {
  "What are latest trends in the healthcare treatment space?": {
    steps: [
      "🔒 Calling Governance Agent...",
      "✅ Governance Agent Authorized",
      "🔐 Calling Authorization and Access Agent...",
      "✅ Authorization and Access Agent Authorized",
      "🔍 Calling Research Agent...",
      "⏳ Research Agent Processing...",
      "✅ Research Agent Completed",
      "📝 Calling Documenting Agent...",
      "⏳ Documenting Agent Processing...",
      "✅ Documentation Completed"
    ],
    finalResponse: "Based on comprehensive research and analysis, here are the latest trends in healthcare treatment space:\n\n1. Gene Editing (CRISPR) and CAR-T Therapy\n2. Precision Medicine\n3. Digital Therapeutics and Telehealth\n4. Wearable Health Technology\n5. Psychedelic-assisted Therapies\n6. Regenerative Medicine\n\nEach of these treatments shows significant promise but requires careful implementation and oversight. Would you like detailed information about any specific trend?"
  },
  "Is implementing this particular healthcare treatment risky?": {
    steps: [
      "🔒 Calling Governance Agent...",
      "✅ Governance Agent Authorized",
      "🔐 Calling Authorization and Access Agent...",
      "✅ Authorization and Access Agent Authorized",
      "⚠️ Calling Risk Assessment Agent...",
      "⏳ Risk Assessment Agent Processing...",
      "✅ Risk Assessment Completed",
      "⚖️ Calling Legal Agent...",
      "⏳ Legal Review in Progress...",
      "✅ Legal Review Completed",
      "📝 Calling Documenting Agent...",
      "⏳ Documenting Agent Processing...",
      "✅ Documentation Completed"
    ],
    finalResponse: "Implementing new healthcare treatments can be risky depending on the type and context. Gene editing (like CRISPR) and CAR-T therapy offer high potential but come with risks such as immune reactions or long-term effects. Precision medicine requires accurate genetic interpretation, and errors can lead to ineffective or harmful outcomes. Digital therapeutics and telehealth are lower-risk biologically but can suffer from data bias or misuse. Wearables are generally safe but need proper validation. Psychedelic-assisted therapies show promise for mental health but remain risky without trained supervision and legal clearance. Regenerative medicine, including stem cells, may cause issues like tissue rejection or uncontrolled growth if not properly controlled. Overall, treatments still in trial phases or needing specialized infrastructure pose higher risks, while digital tools and approved therapies tend to be safer if implemented responsibly. Clinical oversight, regulatory approval, and proper training are essential to reduce risks."
  },
  "Ok now that it is of moderate risk, what is the revenue and profit projection if we implement this heathcare treatment.": {
    steps: [
      "🔒 Calling Governance Agent...",
      "✅ Governance Agent Authorized",
      "🔐 Calling Authorization and Access Agent...",
      "✅ Authorization and Access Agent Authorized",
      "💰 Calling Revenue and Profit Calculation Agent...",
      "⏳ Revenue and Profit Calculation Agent Processing...",
      "✅ Revenue and Profit Calculation Completed",
      "📝 Calling Documenting Agent...",
      "⏳ Documenting Agent Processing...",
      "✅ Documentation Completed"
    ],
    finalResponse: "Based on comprehensive market analysis and risk-adjusted financial modeling:\n\nInitial Investment Required: $8.5M\n\nYear 1 (Market Entry):\n- Revenue: $3.2M\n- Operating Costs: $2.8M\n- Profit Margin: 12.5%\n- Net Profit: $400K\n- Break-even Point: Month 18\n\nYear 2 (Growth Phase):\n- Revenue: $7.5M\n- Operating Costs: $5.8M\n- Profit Margin: 22.7%\n- Net Profit: $1.7M\n- Market Share: 3.5%\n\nYear 3 (Expansion):\n- Revenue: $15.2M\n- Operating Costs: $10.9M\n- Profit Margin: 28.3%\n- Net Profit: $4.3M\n- Market Share: 7.2%\n\nKey Financial Metrics:\n- Internal Rate of Return (IRR): 32%\n- Payback Period: 2.8 years\n- Risk-Adjusted ROI: 285%\n\nNote: These projections account for:\n- Moderate risk profile\n- Regulatory compliance costs\n- Insurance and liability coverage\n- Market competition\n- Technology adoption rates\n\nWould you like a detailed breakdown of any specific aspect of these projections?"
  },
  "What are the latest latest marketing capaigns?": {
    steps: [
      "🔒 Calling Governance Agent...",
      "✅ Governance Agent Authorized",
      "🔐 Calling Authorization and Access Agent...",
      "✅ Authorization and Access Agent Authorized",
      "🔍 Calling Research Agent...",
      "⏳ Research Agent Processing...",
      "✅ Research Agent Completed",
      "📝 Calling Documenting Agent...",
      "⏳ Documenting Agent Processing...",
      "✅ Documentation Completed"
    ],
    finalResponse: "Current Active Marketing Campaigns:\n\n1. Healthcare Innovation Summit 2024\n- Target: Healthcare Executives & Investors\n- Budget: $1.2M\n- Channels: Industry Events, LinkedIn, Medical Journals\n- Key Metrics: 2,500+ registrations, 45% conversion rate\n\n2. Patient-Centric Care Initiative\n- Target: Healthcare Providers & Patients\n- Budget: $850K\n- Channels: Social Media, Healthcare Apps, Patient Portals\n- Key Metrics: 1.8M impressions, 12% engagement rate\n\n3. Digital Health Transformation Program\n- Target: Hospital Networks & Clinics\n- Budget: $1.5M\n- Channels: B2B Platforms, Industry Webinars, Direct Marketing\n- Key Metrics: 150+ qualified leads, 35% conversion rate\n\n4. Medical Technology Showcase\n- Target: Healthcare Professionals\n- Budget: $750K\n- Channels: Medical Conferences, Professional Networks\n- Key Metrics: 3,000+ attendees, 28% lead generation\n\n5. Healthcare Sustainability Campaign\n- Target: Healthcare Organizations & Environmental Stakeholders\n- Budget: $600K\n- Channels: Industry Publications, Sustainability Forums\n- Key Metrics: 500K+ reach, 15% engagement rate\n\nWould you like detailed performance metrics for any specific campaign?"
  },
  "Ok, give some analysis of the ROI of these campaigns.": {
    steps: [
      "🔒 Calling Governance Agent...",
      "✅ Governance Agent Authorized",
      "🔐 Calling Authorization and Access Agent...",
      "✅ Authorization and Access Agent Authorized",
      "📊 Calling Marketing Analytics Agent...",
      "⏳ Marketing Analytics Agent Processing...",
      "✅ Marketing Analytics Completed",
      "📝 Calling Documenting Agent...",
      "⏳ Documenting Agent Processing...",
      "✅ Documentation Completed"
    ],
    finalResponse: "Comprehensive Campaign ROI Analysis:\n\n1. Healthcare Innovation Summit 2024\n- Investment: $1.2M\n- Revenue Generated: $4.8M\n- ROI: 300%\n- Customer Acquisition Cost: $480\n- Lifetime Value: $32,000\n- Payback Period: 3 months\n\n2. Patient-Centric Care Initiative\n- Investment: $850K\n- Revenue Generated: $3.4M\n- ROI: 300%\n- Customer Acquisition Cost: $85\n- Lifetime Value: $2,800\n- Payback Period: 2.5 months\n\n3. Digital Health Transformation Program\n- Investment: $1.5M\n- Revenue Generated: $6.0M\n- ROI: 300%\n- Customer Acquisition Cost: $10,000\n- Lifetime Value: $40,000\n- Payback Period: 3 months\n\n4. Medical Technology Showcase\n- Investment: $750K\n- Revenue Generated: $2.7M\n- ROI: 260%\n- Customer Acquisition Cost: $250\n- Lifetime Value: $9,000\n- Payback Period: 2.8 months\n\n5. Healthcare Sustainability Campaign\n- Investment: $600K\n- Revenue Generated: $1.8M\n- ROI: 200%\n- Customer Acquisition Cost: $1,200\n- Lifetime Value: $3,600\n- Payback Period: 3.6 months\n\nOverall Campaign Performance:\n- Total Investment: $4.9M\n- Total Revenue Generated: $18.7M\n- Average ROI: 282%\n- Average Payback Period: 3.2 months\n- Customer Acquisition Cost: $2,403\n- Average Lifetime Value: $17,480\n\nKey Insights:\n1. All campaigns exceeded the target ROI of 200%\n2. Digital channels show highest efficiency\n3. B2B campaigns have longer sales cycles but higher lifetime value\n4. Patient-focused campaigns show fastest payback\n5. Sustainability campaign shows growing potential\n\nWould you like a detailed breakdown of any specific campaign's performance metrics?"
  }
};

// Mock chat sessions
const mockChatSessions: ChatSession[] = [
  {
    id: "1",
    title: "New Chat",
    useCase: "Healthcare",
    messages: [
      {
        id: "1-1",
        role: "assistant",
        content: "Hello! I'm your friend, MARCUS. How can I help you today?",
        timestamp: new Date("2025-05-05T10:15:00Z")
      }
    ],
    lastUpdated: new Date("2025-05-05T10:15:00Z")
  }
];

const CHAT_STORAGE_KEY = "master_orchestration_chat_sessions";

const Test = () => {
  const [chatSessions, setChatSessions] = useState<ChatSession[]>(() => {
    const stored = localStorage.getItem(CHAT_STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        return parsed.map((session: any) => ({
          ...session,
          lastUpdated: new Date(session.lastUpdated),
          messages: session.messages.map((msg: any) => ({ ...msg, timestamp: new Date(msg.timestamp) }))
        }));
      } catch {
        return mockChatSessions;
      }
    }
    return mockChatSessions;
  });
  const [activeChatId, setActiveChatId] = useState<string>(mockChatSessions[0]?.id || "");
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState<string | null>(null);
  const navigate = useNavigate();
  
  const activeChat = chatSessions.find(chat => chat.id === activeChatId);
  const messages = activeChat?.messages || [];

  useEffect(() => {
    const handleBeforeUnload = () => {
      localStorage.removeItem(CHAT_STORAGE_KEY);
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  useEffect(() => {
    localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(chatSessions));
  }, [chatSessions]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;
    
    const userMessage = input;
    setInput("");
    
    const userMessageObj: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: userMessage,
      timestamp: new Date()
    };
    
    setChatSessions(prev => {
      const updated = [...prev];
      const chatIndex = updated.findIndex(chat => chat.id === activeChatId);
      
      if (chatIndex >= 0) {
        if (updated[chatIndex].title === "New Chat") {
          updated[chatIndex].title = "Healthcare Analysis";
        }
        
        updated[chatIndex] = {
          ...updated[chatIndex],
          messages: [...updated[chatIndex].messages, userMessageObj],
          lastUpdated: new Date()
        };
      }
      
      return updated;
    });
    
    setIsLoading(true);
    
    try {
      const response = hardcodedResponses[userMessage];
      
      if (!response) {
        setIsLoading(false);
        return;
      }

      for (const step of response.steps) {
        const statusMessage: ChatMessage = {
          id: Date.now().toString(),
          role: "system",
          content: step,
          timestamp: new Date(),
          isStatus: true
        };

        setChatSessions(prev => {
          const updated = [...prev];
          const chatIndex = updated.findIndex(chat => chat.id === activeChatId);
          
          if (chatIndex >= 0) {
            updated[chatIndex] = {
              ...updated[chatIndex],
              messages: [...updated[chatIndex].messages, statusMessage],
              lastUpdated: new Date()
            };
          }
          
          return updated;
        });

        await new Promise(resolve => setTimeout(resolve, 800));
      }

      const assistantResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response.finalResponse,
        timestamp: new Date()
      };

      setChatSessions(prev => {
        const updated = [...prev];
        const chatIndex = updated.findIndex(chat => chat.id === activeChatId);
        
        if (chatIndex >= 0) {
          updated[chatIndex] = {
            ...updated[chatIndex],
            messages: [...updated[chatIndex].messages, assistantResponse],
            lastUpdated: new Date()
          };
        }
        
        return updated;
      });
    } catch (error) {
      console.error("Error generating chat response:", error);
      toast.error("Failed to generate response. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const createNewChat = () => {
    const newChat: ChatSession = {
      id: Date.now().toString(),
      title: "New Chat",
      useCase: "Healthcare",
      messages: [
        {
          id: Date.now().toString(),
          role: "assistant",
          content: "Hello! I'm your friend, MARCUS. How can I help you today?",
          timestamp: new Date()
        }
      ],
      lastUpdated: new Date()
    };
    
    setChatSessions([newChat]);
    setActiveChatId(newChat.id);
  };

  const handleDeleteChat = (chatId: string) => {
    setShowDeleteConfirmation(chatId);
  };

  const confirmDeleteChat = (chatId: string) => {
    setChatSessions(prev => prev.filter(chat => chat.id !== chatId));
    if (activeChatId === chatId) {
      const remainingChats = chatSessions.filter(chat => chat.id !== chatId);
      setActiveChatId(remainingChats[0]?.id || "");
    }
    setShowDeleteConfirmation(null);
  };

  const downloadChat = () => {
    if (!activeChat) return;

    const chatContent = activeChat.messages
      .filter(msg => msg.role !== "system")
      .map(msg => `${msg.role === "user" ? "User" : "Assistant"}: ${msg.content}`)
      .join("\n\n");

    const blob = new Blob([chatContent], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `chat-${activeChat.id}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      <div className={`${isSidebarOpen ? 'w-64' : 'w-0'} transition-all duration-300 bg-card border-r border-border/80 overflow-hidden`}>
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Chat History</h2>
            <button
              onClick={createNewChat}
              className="p-2 hover:bg-muted rounded-md transition-colors"
            >
              <Plus size={20} />
            </button>
          </div>
          
          <div className="space-y-2">
            {chatSessions.map(chat => (
              <div
                key={chat.id}
                className={`p-2 rounded-md cursor-pointer flex items-center justify-between group
                  ${activeChatId === chat.id ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}`}
                onClick={() => setActiveChatId(chat.id)}
              >
                <div className="flex items-center gap-2">
                  <MessageSquare size={16} />
                  <span className="truncate">{chat.title}</span>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteChat(chat.id);
                  }}
                  className="opacity-0 group-hover:opacity-100 hover:text-destructive"
                >
                  <X size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        <div className="p-4 border-b border-border/80 flex items-center justify-between">
          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-muted rounded-md transition-colors"
          >
            {isSidebarOpen ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
          </button>
          <h2 className="text-lg font-semibold">Master Orchestration Agent</h2>
          <button
            onClick={downloadChat}
            className="p-2 hover:bg-muted rounded-md transition-colors"
            title="Download Chat"
          >
            <FileDown size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {messages.map(message => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg ${
                  message.role === 'user'
                    ? 'bg-primary text-primary-foreground p-3'
                    : message.role === 'system'
                    ? 'bg-muted/30 text-muted-foreground py-1 px-2 text-sm'
                    : 'bg-muted p-3'
                }`}
              >
                {message.isStatus ? (
                  <div className="flex items-center gap-1.5">
                    {message.content.includes("✅") ? (
                      <Check size={14} className="text-green-500" />
                    ) : null}
                    <span>{message.content}</span>
                  </div>
                ) : (
                  <>
                    <div className="whitespace-pre-wrap">{message.content}</div>
                    <div className="text-xs opacity-70 mt-1">
                      {message.timestamp.toLocaleTimeString()}
                    </div>
                  </>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-muted/30 rounded-lg py-1 px-2 text-sm">
                <div className="animate-pulse">Processing...</div>
              </div>
            </div>
          )}
        </div>

        <div className="p-4 border-t border-border/80">
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Type your message..."
              className="flex-1 p-2 rounded-md border border-border/80 bg-background"
            />
            <button
              onClick={handleSendMessage}
              disabled={isLoading || !input.trim()}
              className="p-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>

      {showDeleteConfirmation && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center">
          <div className="bg-card p-6 rounded-lg max-w-sm">
            <h3 className="text-lg font-semibold mb-4">Delete Chat</h3>
            <p className="mb-4">Are you sure you want to delete this chat? This action cannot be undone.</p>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowDeleteConfirmation(null)}
                className="px-4 py-2 rounded-md bg-muted hover:bg-muted/80"
              >
                Cancel
              </button>
              <button
                onClick={() => confirmDeleteChat(showDeleteConfirmation)}
                className="px-4 py-2 rounded-md bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Test;
