import { useState, useEffect } from "react";
import { Feedback } from "../types";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Plus, X } from "lucide-react";

// Get departments and usecases from localStorage or use defaults
const getDepartmentsAndUsecases = () => {
  const storedUsecases = localStorage.getItem("usecases");
  if (storedUsecases) {
    try {
      return JSON.parse(storedUsecases);
    } catch (error) {
      console.error("Error parsing usecases from localStorage", error);
    }
  }
  
  // Default usecases by department
  return {
    Marketing: ["Business Insights", "Marketing Charts", "Campaign Analysis", "Social Media Strategy", "Brand Monitoring"],
    Sales: ["Sales Presentation", "Competitive Analysis", "Customer Profiling", "Deal Negotiation", "Pipeline Management"],
    Finance: ["Financial Analysis", "Risk Assessment", "Investment Planning", "Budget Forecasting", "Audit Preparation"],
    HR: ["Recruitment", "Performance Evaluation", "Training", "Organizational Development", "Compliance"],
    Operations: ["Process Optimization", "Supply Chain", "Quality Control", "Inventory Management", "Logistics Planning"]
  };
};

// Get feedback from localStorage or use mock data
const getFeedbacks = () => {
  const storedFeedbacks = localStorage.getItem("feedbacks");
  if (storedFeedbacks) {
    try {
      return JSON.parse(storedFeedbacks);
    } catch (error) {
      console.error("Error parsing feedbacks from localStorage", error);
    }
  }
  
  // Mock feedback data
  return {
    "Business Insights": [
      {
        id: "1",
        text: "The prompt should be more focused on actionable insights",
        checked: false,
        resolved: false,
        resolution: "",
      },
      {
        id: "2",
        text: "Add more specific examples for the domain expertise section",
        checked: false,
        resolved: false,
        resolution: "",
      }
    ],
    "Marketing Charts": [
      {
        id: "3",
        text: "The communication style needs to be more technical",
        checked: false,
        resolved: false,
        resolution: "",
      },
      {
        id: "4",
        text: "Consider adding references to common industry tools",
        checked: true,
        resolved: true,
        resolution: "Added references to PowerBI, Tableau, and Google Data Studio in the domain expert areas section.",
      }
    ],
    "Sales Presentation": [
      {
        id: "5",
        text: "The generated prompt is too generic for our specific industry",
        checked: false,
        resolved: false,
        resolution: "",
      },
      {
        id: "6",
        text: "Need more emphasis on data visualization techniques",
        checked: true,
        resolved: true,
        resolution: "Added specific visualization techniques in analytical methods section.",
      }
    ],
    "Financial Analysis": [
      {
        id: "7",
        text: "Include more financial metrics and KPIs",
        checked: true,
        resolved: true,
        resolution: "Added ROI, EBITDA, and cash flow metrics to the domain expertise section.",
      }
    ]
  };
};

interface FeedbackItem extends Feedback {}

interface FeedbacksByUsecase {
  [usecase: string]: FeedbackItem[];
}

const FeedbackPage = () => {
  const [departments, setDepartments] = useState<string[]>([]);
  const [selectedDepartment, setSelectedDepartment] = useState<string>("Marketing");
  const [usecasesByDepartment, setUsecasesByDepartment] = useState<{[key: string]: string[]}>({});
  const [selectedUsecase, setSelectedUsecase] = useState<string>("");
  const [feedbacksByUsecase, setFeedbacksByUsecase] = useState<FeedbacksByUsecase>({});
  const [newFeedback, setNewFeedback] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [resolutionText, setResolutionText] = useState("");
  const [editingFeedbackId, setEditingFeedbackId] = useState<string | null>(null);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState<string | null>(null);

  // Initialize data on component mount
  useEffect(() => {
    const deptAndUsecases = getDepartmentsAndUsecases();
    const depts = Object.keys(deptAndUsecases);
    setDepartments(depts);
    setUsecasesByDepartment(deptAndUsecases);
    
    if (depts.length > 0) {
      setSelectedDepartment(depts[0]);
      const firstDeptUsecases = deptAndUsecases[depts[0]] || [];
      if (firstDeptUsecases.length > 0) {
        setSelectedUsecase(firstDeptUsecases[0]);
      }
    }
    
    setFeedbacksByUsecase(getFeedbacks());
  }, []);

  // Sync with localStorage on feedback change
  useEffect(() => {
    localStorage.setItem("feedbacks", JSON.stringify(feedbacksByUsecase));
  }, [feedbacksByUsecase]);

  // Periodically check for data updates from other components
  useEffect(() => {
    const intervalId = setInterval(() => {
      // Check for usecase updates
      const currentDeptAndUsecases = getDepartmentsAndUsecases();
      if (JSON.stringify(currentDeptAndUsecases) !== JSON.stringify(usecasesByDepartment)) {
        setUsecasesByDepartment(currentDeptAndUsecases);
        setDepartments(Object.keys(currentDeptAndUsecases));
      }
      
      // Check for feedback updates
      const currentFeedbacks = getFeedbacks();
      if (JSON.stringify(currentFeedbacks) !== JSON.stringify(feedbacksByUsecase)) {
        setFeedbacksByUsecase(currentFeedbacks);
      }
    }, 1000);

    return () => clearInterval(intervalId);
  }, [usecasesByDepartment, feedbacksByUsecase]);

  // Update selectedUsecase when department changes
  useEffect(() => {
    if (selectedDepartment && usecasesByDepartment[selectedDepartment]) {
      const usecases = usecasesByDepartment[selectedDepartment];
      if (usecases && usecases.length > 0 && !usecases.includes(selectedUsecase)) {
        setSelectedUsecase(usecases[0]);
      }
    }
  }, [selectedDepartment, usecasesByDepartment]);

  const handleToggleFeedback = (id: string) => {
    setEditingFeedbackId(id);
    const feedback = feedbacksByUsecase[selectedUsecase]?.find(item => item.id === id);
    setResolutionText(feedback?.resolution || "");
  };

  const handleResolveFeedback = () => {
    if (!editingFeedbackId) return;
    
    setFeedbacksByUsecase(prev => {
      const updated = { ...prev };
      if (!updated[selectedUsecase]) {
        updated[selectedUsecase] = [];
      }
      
      updated[selectedUsecase] = updated[selectedUsecase].map(feedback => 
        feedback.id === editingFeedbackId ? 
          { ...feedback, resolved: true, resolution: resolutionText } : 
          feedback
      );
      return updated;
    });
    
    setEditingFeedbackId(null);
    setResolutionText("");
  };

  const handleAddFeedback = () => {
    if (!newFeedback.trim() || !selectedUsecase) return;
    
    setFeedbacksByUsecase(prev => {
      const updated = { ...prev };
      const newItem: FeedbackItem = {
        id: Date.now().toString(),
        text: newFeedback,
        checked: false,
        resolved: false,
        resolution: "",
      };
      
      if (!updated[selectedUsecase]) {
        updated[selectedUsecase] = [];
      }
      
      updated[selectedUsecase] = [...updated[selectedUsecase], newItem];
      return updated;
    });
    
    setNewFeedback("");
  };

  const handleDeleteFeedback = (id: string) => {
    setShowDeleteConfirmation(id);
  };
  
  const confirmDeleteFeedback = (id: string) => {
    setFeedbacksByUsecase(prev => {
      const updated = { ...prev };
      if (updated[selectedUsecase]) {
        updated[selectedUsecase] = updated[selectedUsecase].filter(feedback => feedback.id !== id);
      }
      return updated;
    });
    
    setShowDeleteConfirmation(null);
  };

  const availableUsecases = usecasesByDepartment[selectedDepartment] || [];
  const currentFeedbacks = feedbacksByUsecase[selectedUsecase] || [];
  
  // Filter feedbacks based on search query
  const filteredFeedbacks = searchQuery 
    ? currentFeedbacks.filter(f => 
        f.text.toLowerCase().includes(searchQuery.toLowerCase()) || 
        f.resolution?.toLowerCase().includes(searchQuery.toLowerCase() || '')
      )
    : currentFeedbacks;

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <main className="flex-1 p-3 sm:p-5 max-w-5xl mx-auto w-full">
        <h1 className="text-2xl font-bold mb-5">Feedback Management</h1>
        
        <div className="border border-border rounded-lg overflow-hidden">
          <div className="bg-card p-4 border-b border-border">
            <h2 className="font-semibold mb-4">Manage Feedback</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm mb-1">Department</label>
                <select
                  value={selectedDepartment}
                  onChange={(e) => setSelectedDepartment(e.target.value)}
                  className="w-full bg-muted text-foreground border border-border rounded p-2"
                >
                  {departments.map((dept) => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm mb-1">UseCase</label>
                <select
                  value={selectedUsecase}
                  onChange={(e) => setSelectedUsecase(e.target.value)}
                  className="w-full bg-muted text-foreground border border-border rounded p-2"
                  disabled={availableUsecases.length === 0}
                >
                  {availableUsecases.map((useCase) => (
                    <option key={useCase} value={useCase}>{useCase}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search feedbacks..."
                  className="w-full bg-muted text-foreground border border-border rounded-md px-4 py-2 pl-9"
                />
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newFeedback}
                  onChange={(e) => setNewFeedback(e.target.value)}
                  placeholder="Add new feedback..."
                  className="flex-1 bg-muted text-foreground border border-border rounded-md px-4 py-2"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleAddFeedback();
                  }}
                />
                <button
                  onClick={handleAddFeedback}
                  disabled={!newFeedback.trim() || !selectedUsecase}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground px-3 py-1 rounded-md disabled:opacity-50 flex items-center"
                >
                  <Plus size={16} />
                </button>
              </div>
            </div>
          </div>
          
          <div className="p-4">
            <div className="space-y-3 max-h-[400px] overflow-y-auto">
              {!selectedUsecase ? (
                <p className="text-center text-muted-foreground py-8">
                  Select a usecase to view feedbacks
                </p>
              ) : filteredFeedbacks.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  {searchQuery ? "No matching feedbacks found" : "No feedback available for this usecase"}
                </p>
              ) : (
                filteredFeedbacks.map((feedback) => (
                  <div
                    key={feedback.id}
                    className={`p-3 border rounded-md ${feedback.resolved ? "border-primary/30 bg-primary/5" : "border-border"}`}
                  >
                    <div className="flex items-start gap-3">
                      <div 
                        className={`mt-1 h-5 w-5 rounded border flex-shrink-0 cursor-pointer ${feedback.resolved ? "bg-primary border-primary" : "border-muted-foreground"}`} 
                        onClick={() => handleToggleFeedback(feedback.id)}
                      >
                        {feedback.resolved && (
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary-foreground h-4 w-4 stroke-white"><polyline points="20 6 9 17 4 12"></polyline></svg>
                        )}
                      </div>
                      <div className="flex-1">
                        <p className={feedback.resolved ? "text-muted-foreground" : ""}>
                          {feedback.text}
                        </p>
                        {feedback.resolved && feedback.resolution && (
                          <p className="text-sm text-muted-foreground mt-2 border-t border-border pt-2">
                            <span className="font-medium">Resolution:</span> {feedback.resolution}
                          </p>
                        )}
                        
                        {editingFeedbackId === feedback.id && (
                          <div className="mt-2">
                            <textarea
                              value={resolutionText}
                              onChange={(e) => setResolutionText(e.target.value)}
                              placeholder="Enter resolution details..."
                              className="w-full bg-muted text-foreground border border-border rounded p-2 text-sm h-20 resize-none"
                            ></textarea>
                            <div className="flex justify-end gap-2 mt-2">
                              <button
                                onClick={() => setEditingFeedbackId(null)}
                                className="px-3 py-1 text-sm border border-border rounded"
                              >
                                Cancel
                              </button>
                              <button
                                onClick={handleResolveFeedback}
                                className="px-3 py-1 text-sm bg-primary text-primary-foreground rounded"
                              >
                                Resolve
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                      <button
                        onClick={() => handleDeleteFeedback(feedback.id)}
                        className="text-muted-foreground hover:text-destructive"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </main>
      
      {/* Delete Confirmation */}
      {showDeleteConfirmation && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card rounded-lg p-5 max-w-md w-full">
            <h3 className="text-lg font-medium mb-2">Confirm Delete</h3>
            <p className="mb-4">Are you sure you want to delete this feedback? This action cannot be undone.</p>
            <div className="flex justify-end gap-2">
              <button 
                className="px-4 py-2 border border-border rounded-md hover:bg-secondary/20"
                onClick={() => setShowDeleteConfirmation(null)}
              >
                Cancel
              </button>
              <button 
                className="px-4 py-2 bg-destructive text-destructive-foreground rounded-md hover:bg-destructive/90"
                onClick={() => confirmDeleteFeedback(showDeleteConfirmation)}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FeedbackPage;
