import React from "react";

const About = () => (
  <div className="min-h-screen flex flex-col items-center justify-center bg-background text-foreground p-8">
    <div className="max-w-xl w-full bg-card rounded-lg shadow p-6 border border-border">
      <h1 className="text-3xl font-bold mb-4 text-yellow-700">About Synchrony Prompt Generation Tool</h1>
      <p className="mb-2">Synchrony Prompt Generation Tool is designed to help teams quickly generate, test, and manage expert-level prompts for a variety of business use cases. Whether you are in Marketing, Sales, Finance, or HR, our tool streamlines the process of creating high-quality prompts for LLMs and chatbots.</p>
      <ul className="list-disc pl-6 mb-2">
        <li>Generate expert-mode prompts tailored to your department's needs.</li>
        <li>Test prompts with integrated LLMs and chat interfaces.</li>
        <li>Save, update, and manage prompts in a central PromptDB.</li>
        <li>Collaborate and share feedback with your team.</li>
      </ul>
      <p className="text-muted-foreground">For more information, contact your Synchrony admin or visit our help section.</p>
    </div>
  </div>
);

export default About; 