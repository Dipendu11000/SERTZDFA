import React from "react";

const Help = () => (
  <div className="min-h-screen flex flex-col items-center justify-center bg-background text-foreground p-8">
    <div className="max-w-xl w-full bg-card rounded-lg shadow p-6 border border-border">
      <h1 className="text-3xl font-bold mb-4 text-yellow-700">Help & Support</h1>
      <p className="mb-2">Need assistance with the Synchrony Prompt Generation Tool? Here are some tips to get you started:</p>
      <ul className="list-disc pl-6 mb-2">
        <li>Use the Generate Prompt tab to create new expert prompts for your department.</li>
        <li>Test your prompts in the Test tab and chat with the LLM to refine your results.</li>
        <li>Save your best prompts to the PromptDB for future use and team collaboration.</li>
        <li>Use the Feedback tab to provide suggestions or report issues.</li>
        <li>Switch between light and dark themes for your preferred viewing experience.</li>
      </ul>
      <p className="text-muted-foreground">For further help, contact your Synchrony support team or refer to the documentation provided by your admin.</p>
    </div>
  </div>
);

export default Help; 