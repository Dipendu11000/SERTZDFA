import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import synchronyLogo from "../assets/synchrony-logo.png";

const Signup = () => {
  const navigate = useNavigate();
  const [department, setDepartment] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [signedIn, setSignedIn] = useState(false);

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem("isSignedIn", "true");
    setSignedIn(true);
  };

  useEffect(() => {
    if (signedIn) {
      navigate("/");
    }
  }, [signedIn, navigate]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background text-foreground">
      <div className="flex items-center gap-3 mb-6">
        <img src={synchronyLogo} alt="Synchrony Logo" className="h-10 w-10 rounded" />
        <h1 className="text-2xl font-bold text-yellow-700">Synchrony Prompt Generation Tool</h1>
      </div>
      <form onSubmit={handleSignup} className="bg-card rounded-lg shadow p-8 border border-border w-full max-w-md">
        <h2 className="text-xl font-semibold mb-4 text-center">Sign In</h2>
        <div className="mb-4">
          <label className="block mb-1">Department</label>
          <select
            className="w-full bg-muted text-foreground border border-border rounded p-2"
            value={department}
            onChange={e => setDepartment(e.target.value)}
            required
          >
            <option value="">Select Department</option>
            <option value="Marketing">Marketing</option>
            <option value="Sales">Sales</option>
            <option value="Finance">Finance</option>
            <option value="Legal">Legal</option>
            <option value="Technology">Technology</option>
            <option value="Operations">Operations</option>
            <option value="HR">HR</option>
            <option value="Customer Service">Customer Service</option>
            <option value="Risk">Risk</option>
            <option value="Compliance">Compliance</option>
            <option value="Procurement">Procurement</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div className="mb-4">
          <label className="block mb-1">SSO_ID</label>
          <input
            type="text"
            className="w-full bg-muted text-foreground border border-border rounded p-2"
            value={username}
            onChange={e => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="mb-6">
          <label className="block mb-1">Yubi Key</label>
          <input
            type="password"
            className="w-full bg-muted text-foreground border border-border rounded p-2"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="w-full bg-yellow-400 hover:bg-yellow-500 text-yellow-900 font-semibold py-2 rounded transition-colors">Sign In</button>
      </form>
    </div>
  );
};

export default Signup; 