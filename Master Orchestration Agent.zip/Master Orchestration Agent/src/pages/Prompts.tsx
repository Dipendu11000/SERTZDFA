import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Plus, Search, X } from "lucide-react";

// Get departments and usecases from localStorage or use defaults
const getDepartmentsAndUsecases = () => {
  const storedUsecases = localStorage.getItem("usecases");
  if (storedUsecases) {
    try {
      return JSON.parse(storedUsecases);
    } catch (error) {
      console.error("Error parsing usecases from localStorage", error);
    }
  }
  
  // Default usecases by department
  return {
    Marketing: ["Business Insights", "Marketing Charts", "Campaign Analysis", "Social Media Strategy", "Brand Monitoring"],
    Sales: ["Sales Presentation", "Competitive Analysis", "Customer Profiling", "Deal Negotiation", "Pipeline Management"],
    Finance: ["Financial Analysis", "Risk Assessment", "Investment Planning", "Budget Forecasting", "Audit Preparation"],
    HR: ["Recruitment", "Performance Evaluation", "Training", "Organizational Development", "Compliance"],
    Operations: ["Process Optimization", "Supply Chain", "Quality Control", "Inventory Management", "Logistics Planning"]
  };
};

// Mock saved prompts
const mockSavedPrompts: SavedPrompt[] = [
  {
    id: "1",
    useCase: "Business Insights",
    modelConfig: "Gemini",
    prompt: "1) You are a business intelligence analyst with 8+ years of experience in retail data insights.\n2) Your expertise centers on sales trend analysis, customer segmentation, and inventory optimization using PowerBI, SQL, and Python.\n3) Approach complex datasets methodically by first cleaning data, identifying patterns, and creating executable recommendations.\n4) Apply statistical methods including regression analysis, time series forecasting, and correlation studies when analyzing sales performance.\n5) Break down technical insights into business-relevant action items with clear ROI measurements.\n6) Prioritize data visualization that tells a clear story about business metrics to non-technical stakeholders.\n7) Communicate with precision, using industry terminology when appropriate but avoiding unnecessary jargon.\n8) Always include baseline metrics when presenting growth opportunities or improvement strategies.\n9) Consistently segment findings by relevant business dimensions (region, product category, customer type).\n10) Flag anomalies and outliers before drawing conclusions, especially for unusual sales patterns.\n11) Never make recommendations without supporting data or fail to consider seasonality in trend analysis.\n12) Always consider both short-term tactical moves and long-term strategic implications in your analysis.\n13) Maintain a decision-making framework that balances data-driven insights with practical business constraints.\n14) Approach each analysis with the objective of uncovering actionable intelligence that drives measurable business outcomes.",
    timestamp: "2025-05-06T10:15:00Z",
    parameters: {
      temperature: 0.7,
      topP: 0.9,
      topK: 50,
    },
    department: "Marketing"
  },
  {
    id: "2",
    useCase: "Marketing Charts",
    modelConfig: "Nova Pro",
    prompt: "1) You are a marketing analytics specialist with deep experience in campaign performance measurement and audience targeting.\n2) Your expertise includes multi-channel attribution modeling, cohort analysis, and conversion optimization using Google Analytics, Adobe Analytics, and SQL.\n3) Approach marketing data by first establishing clear KPIs, then analyzing performance across channels with proper attribution modeling.\n4) Use statistical methods including regression, clustering for segmentation, and Markov chains for attribution when appropriate.\n5) Always quantify marketing ROI by connecting spending to conversions and lifetime customer value.\n6) Break down complex marketing funnels into clear visualization stages with conversion rates at each step.\n7) Communicate insights with marketing-specific terminology while making technical concepts accessible to non-technical stakeholders.\n8) Benchmark current performance against historical trends, industry averages, and competitor performance when data is available.\n9) Segment all analyses by relevant dimensions including audience demographics, acquisition channels, and device types.\n10) Flag unusual patterns in campaign performance and identify potential optimization opportunities.\n11) Never ignore statistical significance when reporting on A/B test results or campaign improvements.\n12) Always consider both immediate conversion metrics and longer-term brand impact when evaluating campaigns.\n13) Maintain a decision-making framework that balances data-driven optimization with creative marketing principles.\n14) Approach analytics with the goal of enabling data-informed marketing decisions that maximize both acquisition efficiency and customer lifetime value.",
    timestamp: "2025-05-05T15:30:00Z",
    parameters: {
      temperature: 0.8,
      topP: 0.85,
      topK: 40,
    },
    department: "Marketing"
  },
  {
    id: "3",
    useCase: "Sales Presentation",
    modelConfig: "GPT-4o",
    prompt: "1) You are a sales presentation specialist with extensive experience creating compelling executive-level sales decks and proposals.\n2) Your expertise includes structuring persuasive narratives, creating visual aids, and developing ROI models for B2B sales contexts.\n3) Approach each presentation by first understanding the client's pain points, then crafting a story that positions your solution as the ideal remedy.\n4) Use frameworks including Problem-Solution-Value, SPIN selling methodology, and Before-After-Bridge to structure compelling sales narratives.\n5) Always quantify the tangible business impact of your solution with concrete metrics, case studies and social proof.\n6) Break down complex value propositions into clear, benefit-focused statements that resonate with both technical and business stakeholders.\n7) Communicate with confidence and clarity, using industry-specific language balanced with accessible explanations of technical concepts.\n8) Incorporate interactive elements and questions that engage the audience and allow for discovery of unstated needs.\n9) Structure all presentations with a clear beginning, middle and end, with natural transitions between key points.\n10) Flag potential objections preemptively and address them within the presentation flow.\n11) Never overload slides with text or present features without connecting them to specific benefits and outcomes.\n12) Always conclude with a clear, action-oriented next step that creates momentum in the sales process.\n13) Maintain a consistent focus on the prospect's business objectives rather than your product's technical specifications.\n14) Approach each presentation as an opportunity to demonstrate thought leadership and subject matter expertise in the client's industry.",
    timestamp: "2025-05-04T09:45:00Z",
    parameters: {
      temperature: 0.75,
      topP: 0.9,
      topK: 45,
    },
    department: "Sales"
  },
  {
    id: "4",
    useCase: "Financial Analysis",
    modelConfig: "GPT-4o",
    prompt: "1) You are a financial analyst with 10+ years of experience in corporate financial modeling and valuation.\n2) Your expertise includes discounted cash flow analysis, comparative company analysis, and scenario planning for investment decisions.\n3) Approach financial data systematically by first validating inputs, structuring models with clear assumptions, and testing sensitivity.\n4) Use financial methodologies including NPV/IRR calculations, Monte Carlo simulations, and regression analysis for forecasting.\n5) Always include risk assessments alongside expected returns, with quantified confidence intervals where possible.\n6) Break down complex financial concepts into clear insights that non-finance executives can use for decision-making.\n7) Communicate with precision, using appropriate financial terminology while explaining implications in business terms.\n8) Benchmark analyses against industry standards, historical performance, and strategic objectives.\n9) Structure all financial models with clearly separated inputs, calculations, and outputs for transparency and auditability.\n10) Flag anomalies in financial data and reconcile discrepancies before drawing conclusions.\n11) Never make recommendations without considering both short-term liquidity impacts and long-term value creation.\n12) Always include multiple scenarios (base, upside, downside) in forecasts and strategic recommendations.\n13) Maintain strict objectivity, avoiding confirmation bias when evaluating investment opportunities.\n14) Approach each analysis with the goal of enabling informed financial decisions that optimize capital allocation.",
    timestamp: "2025-05-03T14:20:00Z",
    parameters: {
      temperature: 0.7,
      topP: 0.9,
      topK: 50,
    },
    department: "Finance"
  },
  {
    id: "5",
    useCase: "Recruitment",
    modelConfig: "Gemini",
    prompt: "1) You are a talent acquisition specialist with 8+ years of experience in technical and executive recruiting.\n2) Your expertise includes candidate assessment, structured interviewing techniques, and talent pipeline development.\n3) Approach hiring processes methodically by first defining clear job requirements, then developing multi-stage evaluation frameworks.\n4) Use assessment methods including behavioral interviewing, skills-based tests, and reference validation for comprehensive candidate evaluation.\n5) Always balance technical skill requirements with cultural fit and growth potential when evaluating candidates.\n6) Develop candidate profiles with clear evaluation criteria that minimize unconscious bias in the selection process.\n7) Communicate with candidates professionally, providing timely feedback and maintaining engagement throughout the hiring process.\n8) Structure interview processes that provide consistent evaluation data while creating a positive candidate experience.\n9) Segment recruitment strategies by role type, seniority level, and market conditions to optimize sourcing approaches.\n10) Flag potential hiring risks while focusing on candidate strengths and development potential.\n11) Never make hiring recommendations without considering team dynamics and long-term retention factors.\n12) Always consider both immediate position requirements and future organizational needs when evaluating talent.\n13) Maintain high ethical standards in recruiting practices, ensuring fairness and confidentiality throughout the process.\n14) Approach talent acquisition as a strategic function that directly impacts organizational performance and culture.",
    timestamp: "2025-05-02T11:10:00Z",
    parameters: {
      temperature: 0.65,
      topP: 0.9,
      topK: 50,
    },
    department: "HR"
  },
];

const PromptDB = () => {
  const [savedPrompts, setSavedPrompts] = useState<SavedPrompt[]>(mockSavedPrompts);
  const [selectedPrompt, setSelectedPrompt] = useState<SavedPrompt | null>(null);
  const [selectedDepartment, setSelectedDepartment] = useState<string>("All");
  const [departments, setDepartments] = useState<string[]>(["All"]);
  const [usecasesByDepartment, setUsecasesByDepartment] = useState<{[key: string]: string[]}>({});
  const [isCreateUsecaseModalOpen, setIsCreateUsecaseModalOpen] = useState(false);
  const [newUsecase, setNewUsecase] = useState("");
  const [newUsecaseDept, setNewUsecaseDept] = useState("Marketing");
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState<string | null>(null);
  const navigate = useNavigate();

  // Initialize departments and usecases on component mount
  useEffect(() => {
    const deptAndUsecases = getDepartmentsAndUsecases();
    const depts = Object.keys(deptAndUsecases);
    setDepartments(["All", ...depts]);
    setUsecasesByDepartment(deptAndUsecases);
    
    if (depts.length > 0 && !newUsecaseDept) {
      setNewUsecaseDept(depts[0]);
    }
  }, []);

  // Periodically check for usecase updates from other components
  useEffect(() => {
    const intervalId = setInterval(() => {
      const currentDeptAndUsecases = getDepartmentsAndUsecases();
      if (JSON.stringify(currentDeptAndUsecases) !== JSON.stringify(usecasesByDepartment)) {
        setUsecasesByDepartment(currentDeptAndUsecases);
        setDepartments(["All", ...Object.keys(currentDeptAndUsecases)]);
      }
    }, 1000);

    return () => clearInterval(intervalId);
  }, [usecasesByDepartment]);

  // Filter prompts by department
  const filteredPrompts = selectedDepartment === "All" 
    ? savedPrompts 
    : savedPrompts.filter(prompt => prompt.department === selectedDepartment);

  const handleUpdatePrompt = () => {
    if (!selectedPrompt) return;
    
    // Update the prompt in the database
    const updatedPrompts = savedPrompts.map(prompt => 
      prompt.id === selectedPrompt.id 
        ? { ...prompt, prompt: selectedPrompt.prompt, timestamp: new Date().toISOString() }
        : prompt
    );
    
    setSavedPrompts(updatedPrompts);
    localStorage.setItem("savedPrompts", JSON.stringify(updatedPrompts));
    toast.success("Prompt updated successfully");
  };

  const handleCopyPrompt = () => {
    if (selectedPrompt) {
      navigator.clipboard.writeText(selectedPrompt.prompt);
      toast.success("Prompt copied to clipboard!");
    }
  };
  
  const handleDeletePrompt = (id: string) => {
    setShowDeleteConfirmation(id);
  };
  
  const confirmDeletePrompt = (id: string) => {
    setSavedPrompts(prevPrompts => prevPrompts.filter(prompt => prompt.id !== id));
    
    if (selectedPrompt?.id === id) {
      setSelectedPrompt(null);
    }
    
    setShowDeleteConfirmation(null);
    toast.success("Prompt deleted successfully");
  };
  
  const handleAddUsecase = () => {
    setIsCreateUsecaseModalOpen(true);
  };
  
  const handleCreateUsecase = () => {
    if (newUsecase.trim() === "") return;
    
    // Add the new usecase to the selected department
    const updatedUsecases = { ...usecasesByDepartment };
    
    if (!updatedUsecases[newUsecaseDept]) {
      updatedUsecases[newUsecaseDept] = [];
    }
    
    if (!updatedUsecases[newUsecaseDept].includes(newUsecase)) {
      updatedUsecases[newUsecaseDept].push(newUsecase);
    }
    
    // Save to localStorage for other components to use
    localStorage.setItem("usecases", JSON.stringify(updatedUsecases));
    setUsecasesByDepartment(updatedUsecases);
    
    // Close the modal and reset form
    setIsCreateUsecaseModalOpen(false);
    
    // Navigate to generate prompt page with the new usecase selected
    const queryParams = new URLSearchParams();
    queryParams.set('department', newUsecaseDept);
    queryParams.set('usecase', newUsecase);
    navigate(`/?${queryParams.toString()}`);
    
    toast.success(`New usecase "${newUsecase}" created for ${newUsecaseDept} department`);
    setNewUsecase("");
  };

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <main className="flex-1 p-3 sm:p-5">
        <div className="flex justify-between items-center mb-5">
          <h1 className="text-2xl font-bold">Prompt Database</h1>
          <button 
            className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground px-3 py-2 rounded-md text-sm"
            onClick={handleAddUsecase}
          >
            <Plus size={16} />
            Create Usecase
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="md:col-span-1 border border-border rounded-lg overflow-hidden">
            <div className="bg-card p-4 border-b border-border">
              <h2 className="font-semibold">Prompt Library</h2>
              <div className="mt-2">
                <label className="block text-sm mb-1">Department</label>
                <select
                  value={selectedDepartment}
                  onChange={(e) => setSelectedDepartment(e.target.value)}
                  className="w-full bg-muted text-foreground border border-border rounded p-2"
                >
                  {departments.map((dept) => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="divide-y divide-border max-h-[600px] overflow-y-auto">
              {filteredPrompts.map((prompt) => (
                <div 
                  key={prompt.id}
                  className={`p-4 hover:bg-muted/50 cursor-pointer ${selectedPrompt?.id === prompt.id ? "bg-muted" : ""}`}
                  onClick={() => setSelectedPrompt(prompt)}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="font-medium">{prompt.useCase}</h3>
                      <p className="text-sm text-muted-foreground">{prompt.modelConfig}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(prompt.timestamp).toLocaleDateString()}
                      </p>
                    </div>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeletePrompt(prompt.id);
                      }}
                      className="p-1.5 hover:bg-secondary/80 rounded-full text-muted-foreground hover:text-destructive"
                    >
                      <X size={14} />
                    </button>
                  </div>
                </div>
              ))}
              
              {filteredPrompts.length === 0 && (
                <div className="p-8 text-center text-muted-foreground">
                  No saved prompts for this department
                </div>
              )}
            </div>
          </div>
          
          <div className="md:col-span-2 border border-border rounded-lg overflow-hidden">
            <div className="bg-card p-4 border-b border-border">
              <h2 className="font-semibold">Prompt Details</h2>
            </div>
            <div className="p-4">
              {selectedPrompt ? (
                <div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">UseCase</h3>
                      <p>{selectedPrompt.useCase}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Model</h3>
                      <p>{selectedPrompt.modelConfig}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Created</h3>
                      <p>{new Date(selectedPrompt.timestamp).toLocaleString()}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Parameters</h3>
                      <p>
                        Temp: {selectedPrompt.parameters.temperature}, 
                        Top P: {selectedPrompt.parameters.topP}, 
                        Top K: {selectedPrompt.parameters.topK}
                      </p>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Saved Prompt</h3>
                    <div className="bg-muted/30 rounded-md p-4 whitespace-pre-wrap max-h-[400px] overflow-y-auto">
                      {selectedPrompt.prompt}
                    </div>
                  </div>
                  
                  <div className="mt-6 flex justify-end space-x-2">
                    <button 
                      className="bg-secondary hover:bg-secondary/80 text-foreground px-3 py-1.5 rounded text-sm"
                      onClick={handleCopyPrompt}
                    >
                      Copy
                    </button>
                    <button 
                      className="bg-primary hover:bg-primary/90 text-primary-foreground px-3 py-1.5 rounded text-sm"
                      onClick={handleUpdatePrompt}
                    >
                      Update Prompt
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-8 text-center text-muted-foreground">
                  Select a prompt to view details
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      
      {/* Create Usecase Modal */}
      {isCreateUsecaseModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card rounded-lg p-5 max-w-md w-full">
            <h3 className="text-lg font-medium mb-4">Create New Usecase</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm mb-1">Department</label>
                <select
                  value={newUsecaseDept}
                  onChange={(e) => setNewUsecaseDept(e.target.value)}
                  className="w-full bg-muted text-foreground border border-border rounded p-2"
                >
                  {departments.filter(dept => dept !== "All").map((dept) => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm mb-1">Usecase Name</label>
                <input
                  type="text"
                  value={newUsecase}
                  onChange={(e) => setNewUsecase(e.target.value)}
                  placeholder="Enter usecase name..."
                  className="w-full bg-muted text-foreground border border-border rounded p-2"
                />
              </div>
            </div>
            
            <div className="flex justify-end gap-2 mt-6">
              <button 
                className="px-4 py-2 border border-border rounded-md hover:bg-secondary/20"
                onClick={() => setIsCreateUsecaseModalOpen(false)}
              >
                Cancel
              </button>
              <button 
                className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
                onClick={handleCreateUsecase}
                disabled={!newUsecase.trim()}
              >
                Create Prompt
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Delete Confirmation */}
      {showDeleteConfirmation && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card rounded-lg p-5 max-w-md w-full">
            <h3 className="text-lg font-medium mb-2">Confirm Delete</h3>
            <p className="mb-4">Are you sure you want to delete this prompt? This action cannot be undone.</p>
            <div className="flex justify-end gap-2">
              <button 
                className="px-4 py-2 border border-border rounded-md hover:bg-secondary/20"
                onClick={() => setShowDeleteConfirmation(null)}
              >
                Cancel
              </button>
              <button 
                className="px-4 py-2 bg-destructive text-destructive-foreground rounded-md hover:bg-destructive/90"
                onClick={() => confirmDeletePrompt(showDeleteConfirmation)}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PromptDB;
