import { useState, useEffect } from "react";
import PromptGenerator from "../components/PromptGenerator";
import SystemInstructionsForm from "../components/SystemInstructionsForm";
import GeneratedPromptDisplay from "../components/GeneratedPromptDisplay";
import FeedbackModal from "../components/FeedbackModal";
import { Feedback } from "../types";
import { SystemInstructions, generatePrompt, GenerationParams } from "../services/aiService";
import { useIsMobile } from "../hooks/use-mobile";

// Get all usecases from localStorage or use defaults
const getUsecases = () => {
  const storedUsecases = localStorage.getItem("usecases");
  if (storedUsecases) {
    try {
      return JSON.parse(storedUsecases);
    } catch (error) {
      console.error("Error parsing usecases from localStorage", error);
    }
  }
  
  // Default usecases by department
  return {
    Marketing: ["Business Insights", "Marketing Charts", "Campaign Analysis", "Social Media Strategy", "Brand Monitoring"],
    Sales: ["Sales Presentation", "Competitive Analysis", "Customer Profiling", "Deal Negotiation", "Pipeline Management"],
    Finance: ["Financial Analysis", "Risk Assessment", "Investment Planning", "Budget Forecasting", "Audit Preparation"],
    HR: ["Recruitment", "Performance Evaluation", "Training", "Organizational Development", "Compliance"],
    Operations: ["Process Optimization", "Supply Chain", "Quality Control", "Inventory Management", "Logistics Planning"]
  };
};

// Flatten usecases by department into a single array
const getAllUsecases = () => {
  const usecasesByDepartment = getUsecases();
  const allUsecases: string[] = [];
  
  Object.values(usecasesByDepartment).forEach(usecases => {
    if (Array.isArray(usecases)) {
      usecases.forEach(usecase => {
        if (!allUsecases.includes(usecase)) {
          allUsecases.push(usecase);
        }
      });
    }
  });
  
  return allUsecases;
};

const mockFeedbacks: Feedback[] = [
  {
    id: "1",
    text: "The prompt should be more focused on actionable insights",
    checked: false,
    resolved: false,
    resolution: "",
  },
  {
    id: "2",
    text: "Add more specific examples for the domain expertise section",
    checked: false,
    resolved: false,
    resolution: "",
  },
  {
    id: "3",
    text: "The communication style needs to be more technical",
    checked: false,
    resolved: false,
    resolution: "",
  },
  {
    id: "4",
    text: "Consider adding references to common industry tools",
    checked: true,
    resolved: false,
    resolution: "",
  },
];

const GENERATED_PROMPT_KEY = "synchrony_generated_prompt";

const Index = () => {
  const [generatedPrompt, setGeneratedPrompt] = useState<string>(() => localStorage.getItem(GENERATED_PROMPT_KEY) || "");
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState<boolean>(false);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>(mockFeedbacks);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [allUsecases, setAllUsecases] = useState<string[]>(getAllUsecases());
  const isMobile = useIsMobile();
  
  const [instructions, setInstructions] = useState<SystemInstructions>({
    expertRole: "",
    domainExpertAreas: "",
    analyticalMethods: "",
    defaultActions: "",
    communicationStyle: "",
    donts: "",
    additionalInformation: "",
  });
  
  const [generationParams, setGenerationParams] = useState<GenerationParams>({
    temperature: 0.7,
    topP: 0.9,
    topK: 50,
  });

  // Listen for usecase changes
  useEffect(() => {
    const handleStorageChange = () => {
      setAllUsecases(getAllUsecases());
    };

    // Listen for storage events from other tabs/windows
    window.addEventListener('storage', handleStorageChange);

    // Check for changes periodically in the current tab
    const intervalId = setInterval(() => {
      const currentUsecases = getAllUsecases();
      if (JSON.stringify(currentUsecases) !== JSON.stringify(allUsecases)) {
        setAllUsecases(currentUsecases);
      }
    }, 1000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(intervalId);
    };
  }, [allUsecases]);

  const handleInstructionChange = (field: keyof SystemInstructions, value: string) => {
    setInstructions((prev) => ({ ...prev, [field]: value }));
  };

  const handleGeneratePrompt = async () => {
    setIsGenerating(true);
    try {
      // Call the AI service to generate the prompt
      const result = await generatePrompt(instructions, generationParams);
      setGeneratedPrompt(result);
      localStorage.setItem(GENERATED_PROMPT_KEY, result);
    } catch (error) {
      console.error("Error generating prompt:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  const toggleFeedbackModal = () => {
    setIsFeedbackModalOpen(!isFeedbackModalOpen);
  };

  useEffect(() => {
    localStorage.setItem(GENERATED_PROMPT_KEY, generatedPrompt);
  }, [generatedPrompt]);

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <main className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Left Sidebar - UseCase and Configs */}
        <div className="w-full lg:w-[220px] border-r border-border overflow-y-auto">
          <PromptGenerator 
            onGeneratedPrompt={setGeneratedPrompt}
            generationParams={generationParams}
            setGenerationParams={setGenerationParams}
            availableUseCases={allUsecases}
          />
        </div>

        {/* Middle - System Instructions Form */}
        <div className="flex-1 overflow-y-auto p-2 sm:p-3 border-b lg:border-b-0 lg:border-r border-border">
          <SystemInstructionsForm
            instructions={instructions}
            onChange={handleInstructionChange}
            onGeneratePrompt={handleGeneratePrompt}
            isGenerating={isGenerating}
          />
        </div>

        {/* Right - Generated Context Prompt */}
        <div className="w-full lg:w-[400px] p-2 sm:p-3 overflow-y-auto">
          <GeneratedPromptDisplay 
            generatedPrompt={generatedPrompt} 
            onSaveToDb={handleSaveToDb} 
          />
        </div>
      </main>
      
      {/* Feedback Modal */}
      <FeedbackModal
        isOpen={isFeedbackModalOpen}
        onClose={toggleFeedbackModal}
        feedbacks={feedbacks}
        onUpdateFeedbacks={setFeedbacks}
      />
    </div>
  );
  
  function handleSaveToDb(prompt: string) {
    // In a real implementation, this would save to a database
    console.log("Saving prompt to DB:", prompt);
  }
};

export default Index;
