import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import { TooltipProvider } from "./components/ui/tooltip";
import { useState } from "react";
import Test from "./pages/Chat";

function App() {
  const [isSignedIn, setIsSignedIn] = useState(true);

  return (
    <TooltipProvider>
      <BrowserRouter>
        <Routes>
          <Route
            path="/"
            element={
              isSignedIn ? (
                <Navigate to="/chat" replace />
              ) : (
                <Navigate to="/signin" replace />
              )
            }
          />
          <Route
            path="/chat"
            element={
              isSignedIn ? (
                <Test />
              ) : (
                <Navigate to="/signin" replace />
              )
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
      <Toaster />
    </TooltipProvider>
  );
}

export default App;
