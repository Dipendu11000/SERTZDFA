
export interface Feedback {
  id: string;
  text: string;
  checked: boolean;
  resolved?: boolean;
  resolution?: string;
}

export interface SavedPrompt {
  id: string;
  useCase: string;
  modelConfig: string;
  prompt: string;
  timestamp: string;
  parameters: {
    temperature: number;
    topP: number;
    topK: number;
  };
  department?: string;
}

export interface SystemInstructions {
  expertRole: string;
  domainExpertAreas: string;
  analyticalMethods: string;
  defaultActions: string;
  communicationStyle: string;
  donts: string;
  additionalInformation: string;
}
